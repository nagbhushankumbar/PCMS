<?php
	session_start();
		$db= mysqli_connect("localhost","root","","pcms");
?>
<html>
<head>
	<title>admin login try</title>
</head>
<body>
	<table align="center" border="2">
	<form action="" method="POST">
		<tr>
			<td colspan="2">LOgin admin</td>
		</tr>
		<tr>
			<td>Username</td>
			<td><input type="text" name="username"/></td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="password" name="password"/></td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" name="login" value="login"></td>
		</tr>
	</form>
	</table>
	<?php
		if(isset($_POST['login'])){
			$username=$_POST['username'];
			$password=$_POST['password'];


			$query="SELECT * from  admin where username='$username' AND password='$password'";

			$run=mysqli_query($db,$query);
			
			if(mysqli_num_rows($run)>0)
			{	
				$_SESSION['username']=$username;
				echo "<script>window.open('AdminPanel.php','_self')</script>";
			}
			else
			{
				echo "<script>alert('Invalid User !!!')</script>";
			}
			//$_SESSION=array();
			//session_destroy();
		}	
	?>
	
</body>
</html>