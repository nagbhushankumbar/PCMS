<?php
session_start();
header("location:admin.php");
session_destroy();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Logout</title>
</head>
<body>
<h1>You are logged out.</h1>
</body>
</html>