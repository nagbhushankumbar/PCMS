<?php
session_start();
if(!isset($_SESSION['username'])){
	header("location:admin.php");
}else{

?>
<!DOCTYPE html>
<html>
<head>
	<title>IICMR PLACEMENT CELL</title>

	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<script src="jquery-3.4.1.min.js"></script>
	<link href="fotorama.css" rel="stylesheet">
 	<script src="fotorama.js"></script>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  	<style type="text/css">
	#drp1
	{	
		color: white;
	}
	#drp1:hover
	{
		color: black;
	}

	#drp
	{	
		color: white;
	}
	#drp:hover
	{
		color: black;
	}
</style>
</head>
<body class="container-fluid">
	
	<!--Contact Details-->
<div style="border-bottom: 5px solid orange;">
	<nav class="nav navbar-default" style="background-color:#045c73;">
		<ul class="nav navbar-nav ">		
			<li><a href="https://www.facebook.com/mcaiicmr/" class="fa fa-facebook" style="font-size:20px;color:white"></a></li>	
			<li><a class="fa fa-phone" style="font-size:20px;color:white"><font face="verdana" size="2"> &nbsp; 020-27657648 / 27650011</font></a></li>
			<li><a class="fa fa-envelope" style="font-size:20px;color:white"><font face="verdana" size="2"> &nbsp; info@iicmr.org</font></a></li>

		</ul>	
	</nav>
</div></body>
<!--Header part-->
<div style="border-bottom: 5px solid orange;">
		<nav class="navbar-default text-center" style="font-family: verdana;">
			<nav class="nav navbar-nav"><br><a href="home.php"><img src="pics/lo1.png" style="margin-left: 10%;" height="100" ></a></nav><br>
			<b>Audyogik Tantra Shikshan Sanstha's ( A.T.S.S. )</b>
			<h2><span style="color:maroon; font-weight: bold;">I</span><span style="color:#073767">nstitute</span> <span style="color:maroon; font-weight: bold;">O</span><span style="color:#073767">f</span> <span style="color:maroon; font-weight: bold;">I</span><span style="color:#073767">ndustrial</span> 
				<span style="color:maroon; font-weight: bold;">A</span><span style="color:#073767">nd</span> <span style="color:maroon; font-weight: bold;">C</span><span style="color:#073767">omputer</span> <span style="color:maroon; font-weight: bold;">M</span><span style="color:#073767">anagement</span> <span style="color:maroon; font-weight: bold;">A</span>nd 
				<span style="color:maroon; font-weight: bold;">R</span><span style="color:#073767">esearch</span></h2>
				<b>(Approved by AICTE & Affiliated to Savitribai Phule Pune University, Recognized by Gov. of Maharashtra,Accredited by NAAC)</b>	
		</nav>
<br/>
</div>

<!--Menu bar-->
<div  style="border-bottom: 5px solid orange;">
	<nav class="nav navbar-default" style="background-color:#045c73;">
		<ul class="nav navbar-nav row">
			<li><p style="margin-left: 2em;margin-right: 2em; padding-top: 7px; color: white;font-family: verdana; font-size: 25px; font-weight: bold;">IICMR PLACEMENT CELL</p></li>

			<li><a href="home.php" style="font-family: verdana;font-size: 17px; " id="drp1"><span class="glyphicon glyphicon-home"></span>&nbsp;Home</a></li>
			
			<li class="dropdown ">
		        <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="font-family: verdana;font-size: 17px;" id="drp1">Report<span class="caret"></span></a>
		        <ul class="dropdown-menu" style="background-color:#045c73; font-size: 15px;">
		          <li><a href="#" id="drp">Placed Students</a></li>
		          <li><a href="#" id="drp">Unplaced Students</a></li>
		          <li><a href="#" id="drp">Company Report</a></li>
		           <li><a href="#" id="drp">Job Report</a></li>
		        </ul>
		    </li>

		    <li class="dropdown">
		        <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="font-family: verdana;font-size: 17px;" id="drp1">Student<span class="caret"></span></a>
		        <ul class="dropdown-menu" style="background-color:#045c73; font-size: 15px;">
		          <li><a href="#" id="drp">Add Student</a></li>
		          <li><a href="#" id="drp">Delete Student</a></li>
		          <li><a href="#" id="drp">Update Student Details</a></li>
		      	</ul>
		    </li>

		    <li><a class="dropdown-toggle" data-toggle="dropdown" href="#" style="font-family: verdana;font-size: 17px;" id="drp1">			Interview Details</a>
		    </li>
		    
		</ul>
	</nav>
</div>
<!-- NOTICE  MArquee -->
<div class="container-fluid" style="background-color: maroon; color: white;">
	<marquee scrollamount=10>Helloooo IICMR</marquee>

</div>
<br><br>
<h3>Welcome <?php echo $_SESSION['username'];?></h3>

<a href="logout.php">LOGOUT</a>
<!--Start of Buttons-->

<div align="center" >
<form method="post" >
	<h2><u>Details of Placed & Unplaced Students</u></h2>
<table>
<tr>
<td>
<b> Student Name : </b></td>
<td><input type="text" class="form-control" name="student_name" />
</td>
</tr>
<tr>
<td>
<b>Email ID : </b></td>
<td><input type="text" class="form-control" name="email" />
</td>
</tr>
<tr>
<td>
<b>class : </b></td>
<td><input type="text" class="form-control" name="class" />
</td>
</tr>
<tr>
<td>
<b>Company Name : </b></td>
<td><input type="text" class="form-control" name="compnayname" />
</td>
</tr>
</table>
<div class="container-fluid">
	<div class="well col-sm-4">
		<input type="submit" class="btn btn-success" name="add_student" value="Add Placed Student"/>
	</div>
	<div class="well col-sm-4">
		<input type="submit" class="btn btn-success" name="delete_student" value="Delete Student"/>
	</div>
	<div class="well col-sm-4">
		<input type="submit" class="btn btn-success" name="view_record" value="View Placed Student"/>
	</div>
</div>
</form>
</div>
<div class="col-sm-12">
	<?php 	
	$db= mysqli_connect("localhost","root","","pcms");
	//for insert Placed student record.
	if(isset($_POST['add_student']))
	{
			$student_name=$_POST['student_name'];
			$email=$_POST['email'];
			$class=$_POST['class'];
			$compnayname=$_POST['compnayname'];
		
		$query="INSERT INTO `addstudent`(`student_name`, `email`, `class`, `compnayname`) VALUES ('$student_name','$email','$class','$compnayname')";
		
		$run=mysqli_query($db,$query);
	
	if($run==true)
	{
		echo "Data inserted Succsesfully.";
	}
	else
	{
		echo "error occur Please try again !";
	}

	}
	
	//for delete record.
	
	if(isset($_POST['delete_student']))
	{
		$email=$_POST['email'];
		
		
		$query="DELETE FROM `addstudent` WHERE email='$email'" ;
		
		$run=mysqli_query($db,$query);
	
	if($run==true)
	{
		echo "Student Data deleted Succsesfully !";
	}
	else
	{
		echo "error occur data is not deleted";
	}

	}
	//to view all records
	
	if(isset($_POST['view_record']))
	{
		$class=$_POST['class'];
		
		
		$query="SELECT * FROM `addstudent`" ;
		
		echo '<table border="2" cellspacing="4" cellpadding="5"> 
      <tr> 
          <td> <font face="verdana">Student Name</font> </td> 
          <td> <font face="verdana">Email Address</font> </td> 
          <td> <font face="verdana">Class</font> </td> 
          <td> <font face="verdana">Compnay Name</font> </td> 
      </tr>';
 
if ($result = $db->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $student_name = $row["student_name"];
        $email = $row["email"];
        $class = $row["class"];
        $compnayname = $row["compnayname"];
 
        echo '<tr> 
                  <td>'.$student_name.'</td> 
                  <td>'.$email.'</td> 
                  <td>'.$class.'</td> 
                  <td>'.$compnayname.'</td> 
              </tr>';
    }
    $result->free();
}
} 

//dep number view

if(isset($_POST['grp_report']))
	{
		
		$deptno=$_POST['deptno'];
		
		$query="SELECT `empno`, `name`, `address`, `salary`, `deptno` FROM `emp` WHERE deptno='$deptno' " ;
		
		echo '<table border="0" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Coloum_1</font> </td> 
          <td> <font face="Arial">Coloum_2</font> </td> 
          <td> <font face="Arial">Coloum_3</font> </td> 
          <td> <font face="Arial">Coloum_4</font> </td> 
          <td> <font face="Arial">Coloum_5</font> </td> 
      </tr>';
 
if ($result = $db->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["empno"];
        $field2name = $row["name"];
        $field3name = $row["address"];
        $field4name = $row["salary"];
        $field5name = $row["deptno"]; 
 
        echo '<tr> 
                  <td>'.$field1name.'</td> 
                  <td>'.$field2name.'</td> 
                  <td>'.$field3name.'</td> 
                  <td>'.$field4name.'</td> 
                  <td>'.$field5name.'</td> 
              </tr>';
    }
    $result->free();
}
}

?>
</div>


</body>
</html>
<?php } ?>